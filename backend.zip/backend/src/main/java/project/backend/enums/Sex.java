package project.backend.enums;

public enum Sex {
    MALE,
    FEMALE
}