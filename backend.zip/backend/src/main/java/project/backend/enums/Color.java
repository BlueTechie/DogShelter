package project.backend.enums;


public enum Color {
    BROWN,
    WHITE,
    BLACK,
    GRAY,
    GOLDEN,
    MIXED
}
